# vpnConnect
Helper tool for connecting to VPN at IT-Services (ITSH)

Na jó, inkább magyarul, a célközönség úgyis helyi. :)

## Leírás
A tool egyszerű [AutoIt](https://www.autoitscript.com/site/autoit/) script, amely megkönnyíti a VPN-hez valo kapcsolodast az It-Services-nél.

A jelszavakat titkosítva menti le az exe mellett. Amennyiben a file nem létezik, bekéri a jelszavakat, majd létrehozza a titkositott file-t.

## Használat
TODO



